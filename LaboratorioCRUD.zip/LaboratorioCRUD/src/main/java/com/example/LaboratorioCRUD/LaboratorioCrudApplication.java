package com.example.LaboratorioCRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaboratorioCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(LaboratorioCrudApplication.class, args);
    }
}
