package com.example.LaboratorioCRUD.controller;

import com.example.LaboratorioCRUD.model.Estudiante;
import com.example.LaboratorioCRUD.service.EstudianteService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteController {

    private final EstudianteService service;

    public EstudianteController(EstudianteService service) {
        this.service = service;
    }

    @GetMapping
    public List<Estudiante> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Estudiante obtener(@PathVariable int id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public Estudiante crear(@RequestBody Estudiante estudiante) {
        return service.crear(estudiante);
    }

    @PutMapping("/{id}")
    public Estudiante actualizar(@PathVariable int id, @RequestBody Estudiante estudiante) {
        return service.actualizar(id, estudiante);
    }

    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable int id) {
        return service.eliminar(id)
                ? "Estudiante eliminado"
                : "Estudiante no encontrado";
    }
}
