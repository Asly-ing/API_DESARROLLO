package com.example.LaboratorioCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaboratorioCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
